/*
 * Tabelle.java -- Variablentabelle
 */


class Tabelle {

  /*
   * Erzeugt eine leere Tabelle.
   */
  Tabelle() {
    /******************************/
    /* Das muessen Sie schreiben! */
    /******************************/
  }

  /*
   * Erzeugt eine geaenderte Tabelle.
   */
  Tabelle(String n, int w, Tabelle t) {
    /******************************/
    /* Das muessen Sie schreiben! */
    /******************************/
  }

  /*
   * Sucht den Wert einer Variablen in der Tabelle und gibt
   * ihn zurueck (Fehlerabbruch, falls nicht gefunden).
   */
  int sucheWert(String n) {
    /******************************/
    /* Das muessen Sie schreiben! */
    /******************************/
    return 0;
  }

}

/*
 * Type.java -- type representation
 */


package types;


public abstract class Type {

  public abstract void show();

}

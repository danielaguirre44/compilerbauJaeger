/*
 * Exp.java -- abstract syntax for expressions
 */


package absyn;

import sym.Sym;


public abstract class Exp extends Absyn {

  public abstract void show(int n);

}

/*
 * Stm.java -- abstract syntax for statements
 */


package absyn;

import sym.Sym;


public abstract class Stm extends Absyn {

  public abstract void show(int n);

}

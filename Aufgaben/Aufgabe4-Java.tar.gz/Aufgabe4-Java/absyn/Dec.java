/*
 * Dec.java -- abstract syntax for declarations
 */


package absyn;

import sym.Sym;


public abstract class Dec extends Absyn {

  public abstract void show(int n);

}
